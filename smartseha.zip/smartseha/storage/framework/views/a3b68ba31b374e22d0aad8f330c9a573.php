<?php $__env->startSection('content'); ?>
<div class="mb-6 flex items-center justify-between">
    <h1 class="page-title">لوحة تحكم الإدارة</h1>
    <span class="rounded-lg bg-slate-900 px-3 py-2 text-xs font-bold text-white">Admin</span>
</div>

<div class="mb-6 grid gap-4 md:grid-cols-2">
    <div class="glass-card p-5">
        <p class="text-sm text-slate-500">إجمالي المستخدمين</p>
        <p class="mt-2 text-3xl font-black text-emerald-700"><?php echo e($stats['total_users']); ?></p>
    </div>
    <div class="glass-card p-5">
        <p class="text-sm text-slate-500">عدد المشرفين</p>
        <p class="mt-2 text-3xl font-black text-emerald-700"><?php echo e($stats['admin_users']); ?></p>
    </div>
</div>

<div class="glass-card p-6 mb-6">
    <h2 class="mb-4 text-lg font-black">إعدادات النظام والذكاء الاصطناعي</h2>

    <form method="POST" action="<?php echo e(route('admin.settings.update')); ?>" class="grid gap-4 md:grid-cols-2">
        <?php echo csrf_field(); ?>

        <div>
            <label class="mb-1 block text-sm font-semibold">اسم الموقع</label>
            <input name="site_name" value="<?php echo e($settings['site_name']); ?>" class="form-input" required>
        </div>

        <div>
            <label class="mb-1 block text-sm font-semibold">موديل AI</label>
            <select name="ai_model" class="form-input" required>
                <?php $__currentLoopData = ['gpt-4o-mini', 'gpt-4.1-mini', 'gpt-4o']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($model); ?>" <?php if($settings['ai_model'] === $model): echo 'selected'; endif; ?>><?php echo e($model); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="md:col-span-2">
            <label class="mb-1 block text-sm font-semibold">AI API Key (اختياري للتحديث)</label>
            <input type="password" name="ai_api_key" class="form-input" placeholder="sk-...">
        </div>

        <div class="md:col-span-2">
            <label class="inline-flex items-center gap-2 text-sm font-semibold">
                <input type="hidden" name="ai_enabled" value="0">
                <input type="checkbox" name="ai_enabled" value="1" <?php if($settings['ai_enabled']): echo 'checked'; endif; ?>>
                تفعيل ميزات AI
            </label>
            <p class="mt-1 text-xs text-slate-500">
                عند التفعيل: النظام يستخدم نموذج الذكاء الاصطناعي لتحليل صور الطعام وإنشاء توصيات صحية أكثر تخصيصًا حسب بيانات المستخدم.
                عند التعطيل: النظام يعمل بقواعد داخلية ثابتة بدون استدعاء AI، وتظل المنصة تعمل بشكل طبيعي لكن بدقة تخصيص أقل.
            </p>
        </div>

        <div>
            <label class="mb-1 block text-sm font-semibold">نقاط استكمال الملف</label>
            <input type="number" name="points_profile" value="<?php echo e($settings['points_profile']); ?>" class="form-input" required>
        </div>
        <div>
            <label class="mb-1 block text-sm font-semibold">نقاط إدخال القياسات</label>
            <input type="number" name="points_health" value="<?php echo e($settings['points_health']); ?>" class="form-input" required>
        </div>
        <div>
            <label class="mb-1 block text-sm font-semibold">نقاط التوصيات</label>
            <input type="number" name="points_recommendation" value="<?php echo e($settings['points_recommendation']); ?>" class="form-input" required>
        </div>
        <div>
            <label class="mb-1 block text-sm font-semibold">نقاط تحليل الوجبة</label>
            <input type="number" name="points_food" value="<?php echo e($settings['points_food']); ?>" class="form-input" required>
        </div>

        <div>
            <label class="mb-1 block text-sm font-semibold">مستوى Silver</label>
            <input type="number" name="level_silver" value="<?php echo e($settings['level_silver']); ?>" class="form-input" required>
        </div>
        <div>
            <label class="mb-1 block text-sm font-semibold">مستوى Gold</label>
            <input type="number" name="level_gold" value="<?php echo e($settings['level_gold']); ?>" class="form-input" required>
        </div>
        <div>
            <label class="mb-1 block text-sm font-semibold">مستوى Platinum</label>
            <input type="number" name="level_platinum" value="<?php echo e($settings['level_platinum']); ?>" class="form-input" required>
        </div>

        <div class="md:col-span-2">
            <button class="primary-btn w-full">حفظ إعدادات النظام</button>
        </div>
    </form>
</div>

<div class="glass-card p-6">
    <h2 class="mb-4 text-lg font-black">إدارة المستخدمين</h2>

    <div class="overflow-auto">
        <table class="w-full min-w-[720px] text-sm">
            <thead>
                <tr class="border-b bg-slate-50 text-right text-slate-500">
                    <th class="p-3">ID</th>
                    <th class="p-3">الاسم</th>
                    <th class="p-3">البريد</th>
                    <th class="p-3">الدور</th>
                    <th class="p-3">إجراء</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="p-3"><?php echo e($user->id); ?></td>
                        <td class="p-3"><?php echo e($user->name); ?></td>
                        <td class="p-3"><?php echo e($user->email); ?></td>
                        <td class="p-3"><?php echo e($user->is_admin ? 'Admin' : 'User'); ?></td>
                        <td class="p-3">
                            <?php if(auth()->id() !== $user->id): ?>
                                <form method="POST" action="<?php echo e(route('admin.users.role', $user)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="is_admin" value="<?php echo e($user->is_admin ? 0 : 1); ?>">
                                    <button class="rounded-lg bg-slate-800 px-3 py-2 text-xs font-bold text-white">
                                        <?php echo e($user->is_admin ? 'إزالة الإدارة' : 'جعله Admin'); ?>

                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4"><?php echo e($users->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'لوحة تحكم الإدارة'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/omar/sites/smartseha/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>